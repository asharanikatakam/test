cd ~/Desktop/Project/projectvalidation/WingsT2-creditcard-validation/

cp  ~/Desktop/Project/WingsT2-creditcard-challenge/*.txt   ~/Desktop/Project/projectvalidation/WingsT2_creditcard_validation/
cp  ~/Desktop/Project/WingsT2-creditcard-challenge/*.java   ~/Desktop/Project/projectvalidation/WingsT2_creditcard_validation/


#!/bin/bash

SCORE=0

PASS=0

FAIL=7

TOTAL_TESTS=7



hdfs dfs -cat /user/labuser/sqoopinput/part-m-00000 | wc -l > sqoopimportcount.txt
TEST_1=$( grep -e "565" sqoopimportcount.txt | wc -l )
if [ $TEST_1 -ge 1 ]
then 
echo "1"
PASS=$((PASS + 20))
FAIL=$((FAIL - 1))
fi;


hdfs dfs -ls /user/labuser/sqoopinput  > output1.txt
TEST_2=$( grep -e "SUCCESS" output1.txt | wc -l )
if [ $TEST_2 -eq 1 ]
then 
echo "2"
PASS=$((PASS + 10))
FAIL=$((FAIL - 1))
fi;


hdfs dfs -ls /user/labuser/pigoutput  > output2.txt
TEST_3=$( grep -e "SUCCESS" output2.txt | wc -l )
if [ $TEST_3 -eq 1 ]
then 
echo "3"
PASS=$((PASS + 10))
FAIL=$((FAIL - 1))
fi;

hdfs dfs -cat /user/labuser/pigoutput/part-m-00000 | wc -l > pigoutputcount.txt
TEST_4=$( grep -e "438" pigoutputcount.txt | wc -l )
if [ $TEST_4 -ge 1 ]
then 
echo "4"
PASS=$((PASS + 20))
FAIL=$((FAIL - 1))
fi;


hdfs dfs -ls /user/labuser/sparkoutput > output3.txt
TEST_5=$( grep -e "SUCCESS" output3.txt | wc -l )
if [ $TEST_5 -ge 1 ]
then 
echo "5"
PASS=$((PASS + 10))
FAIL=$((FAIL - 1))
fi;

hdfs dfs -cat /user/labuser/sparkoutput/part* | wc -l > sparkoutputcount.txt
TEST_6=$( grep -e "91" sparkoutputcount.txt | wc -l )
if [ $TEST_6 -ge 1 ]
then 
echo "6"
PASS=$((PASS + 20))
FAIL=$((FAIL - 1))
fi;

hdfs dfs -cat /user/labuser/sparkoutput/part* > sparkoutputdata.txt
TEST_7=$( grep -io -e "711048783" -e "708331758" -e "GFTC8480BA" -e "OXIDHD2102" -e "714030183" sparkoutputdata.txt | wc -l )
if [ $TEST_7 -ge 5 ]
then 
echo "7"
PASS=$((PASS + 10))
FAIL=$((FAIL - 1))
fi;






echo "Total testcases: $TOTAL_TESTS"

echo "Total testcase failed: $FAIL"

SCORE=$PASS

echo "{SCORE:$SCORE%}"
