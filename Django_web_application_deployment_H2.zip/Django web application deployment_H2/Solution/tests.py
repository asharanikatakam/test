from django.test import TestCase
from rest_framework import status
from rest_framework.test import APITestCase
from rest_framework.test import APIClient
from rest_framework.utils import json
from .models import Task


class TestCase(APITestCase):

    def setUp(self):
        self.client=APIClient()

    def test_add_task_without_title(self):
        payload = {'title': '', 'priority': 'Urgent', 'startdate': '2022-01-01', 'enddate': '2022-01-02', 'status': 'In Progress', 'assignto': 'Mark'}
        response = self.client.post('/add/task', data=payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        response_content = response.content.decode('utf-8')
        self.assertJSONEqual(response_content, {"title": ["This field may not be blank."]})
        

    def test_add_task_without_priority(self):
        payload = {'title': 'Fix Bug', 'priority': '', 'startdate': '2022-01-01', 'enddate': '2022-01-02', 'status': 'In Progress', 'assignto': 'Mark'}
        response = self.client.post('/add/task', data=payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        response_content = response.content.decode('utf-8')
        self.assertJSONEqual(response_content, {"priority": ["\"\" is not a valid choice."]})
    
    def test_add_task_without_startdate(self):
        payload = {'title': 'Fix Bug', 'priority': 'Urgent', 'startdate': '', 'enddate': '2022-01-02', 'status': 'In Progress', 'assignto': 'Mark'}
        response = self.client.post('/add/task', data=payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        response_content = response.content.decode('utf-8')
        self.assertJSONEqual(response_content, {"startdate": ["Date has wrong format. Use one of these formats instead: YYYY-MM-DD."]})

    def test_add_task_with_incorrect_enddate_format(self):
        payload = {'title': 'Fix Bug', 'priority': 'Urgent', 'startdate': '2022-01-01', 'enddate': '01-02-2022', 'status': 'In Progress', 'assignto': 'Mark'}
        response = self.client.post('/add/task', data=payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        response_content = response.content.decode('utf-8')
        self.assertJSONEqual(response_content, {"enddate": ["Date has wrong format. Use one of these formats instead: YYYY-MM-DD."]})

    def test_add_task_without_status(self):
        payload = {'title': 'Fix Bug', 'priority': 'Urgent', 'startdate': '2022-01-01', 'enddate': '2022-01-02', 'status': '', 'assignto': 'Mark'}
        response = self.client.post('/add/task', data=payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        response_content = response.content.decode('utf-8')
        self.assertJSONEqual(response_content, {"status": ["\"\" is not a valid choice."]})

    def test_add_task_without_assignto(self):
        payload = {'title': 'Fix Bug', 'priority': 'Urgent', 'startdate': '2022-01-01', 'enddate': '2022-01-02', 'status': 'In Progress', 'assignto': ''}
        response = self.client.post('/add/task', data=payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        response_content = response.content.decode('utf-8')
        self.assertJSONEqual(response_content, {"assignto": ["This field may not be blank."]})

    def test_add_task(self):
        # add
        payload = {'title': 'Fix Bug', 'priority': 'Urgent', 'startdate': '2022-01-01', 'enddate': '2022-01-02', 'status': 'In Progress', 'assignto': 'Mark'}
        response = self.client.post('/add/task', data=payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        response_content = response.content.decode('utf-8')
        self.assertJSONEqual(response_content, {"message": "Task added successfully."})

        
    def test_list_task(self):      
        Payload1 = Task.objects.create(title='Fix Bug', priority='Urgent', startdate='2022-01-01', enddate='2022-01-02', status= 'In Progress', assignto='Mark') 
        Payload2 = Task.objects.create(title='Resolve Tickets', priority='Low', startdate='2022-01-03', enddate='2022-01-04', status='Backlog', assignto='John')
        Payload3 = Task.objects.create(title='Azure Session', priority='Medium', startdate='2022-01-05', enddate='2022-01-05', status='Backlog', assignto='David')
        
        # list 
        response = self.client.get('/list/task')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        response_content = response.content.decode('utf-8')
        self.assertJSONEqual(response_content, [{"id": 1, "title": "Fix Bug", "priority": "Urgent", "startdate": "2022-01-01", "enddate": "2022-01-02", "status": "In Progress", "assignto": "Mark"}, {"id": 2, "title": "Resolve Tickets", "priority": "Low", "startdate": "2022-01-03", "enddate": "2022-01-04", "status": "Backlog", "assignto": "John"}, {"id": 3, "title": "Azure Session", "priority": "Medium", "startdate": "2022-01-05", "enddate": "2022-01-05", "status": "Backlog", "assignto": "David"}])


    def test_filter_task(self):
        Payload1 = Task.objects.create(title='Fix Bug', priority='Urgent', startdate='2022-01-01', enddate='2022-01-02', status= 'In Progress', assignto='Mark') 
        Payload2 = Task.objects.create(title='Resolve Tickets', priority='Low', startdate='2022-01-03', enddate='2022-01-04', status='Backlog', assignto='John')
        Payload3 = Task.objects.create(title='Azure Session', priority='Medium', startdate='2022-01-05', enddate='2022-01-05', status='Backlog', assignto='David')
        
        # filter
        response = self.client.get('/filter/task/?status=Backlog')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        response_content = response.content.decode('utf-8')   
        self.assertJSONEqual(response_content, [{"id": 2, "title": "Resolve Tickets", "priority": "Low", "startdate": "2022-01-03", "enddate": "2022-01-04", "status": "Backlog", "assignto": "John"}, {"id": 3, "title": "Azure Session", "priority": "Medium", "startdate": "2022-01-05", "enddate": "2022-01-05", "status": "Backlog", "assignto": "David"}])


    def test_update_task(self):
        Payload1 = Task.objects.create(title='Fix Bug', priority='Urgent', startdate='2022-01-01', enddate='2022-01-02', status= 'In Progress', assignto='Mark') 
        Payload2 = Task.objects.create(title='Resolve Tickets', priority='Low', startdate='2022-01-03', enddate='2022-01-04', status='Backlog', assignto='John')
        Payload3 = Task.objects.create(title='Azure Session', priority='Medium', startdate='2022-01-05', enddate='2022-01-05', status='Backlog', assignto='David')
 
        # update
        payload = {'enddate': '2022-01-04'}
        response = self.client.patch('/update/task/4', data=payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
        response_content = response.content.decode('utf-8')
        self.assertJSONEqual(response_content, {"detail": "Not found."})

        payload = {'enddate': '2022-01-04'}
        response = self.client.patch('/update/task/2', data=payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        response_content = response.content.decode('utf-8') 
        self.assertJSONEqual(response_content, {"id": 2, "title": "Resolve Tickets", "priority": "Low", "startdate": "2022-01-03", "enddate": "2022-01-04", "status": "Backlog", "assignto": "John"})


    def test_delete_task(self):
        Payload1 = Task.objects.create(title='Fix Bug', priority='Urgent', startdate='2022-01-01', enddate='2022-01-02', status= 'In Progress', assignto='Mark') 
        Payload2 = Task.objects.create(title='Resolve Tickets', priority='Low', startdate='2022-01-03', enddate='2022-01-04', status='Backlog', assignto='John')
        Payload3 = Task.objects.create(title='Azure Session', priority='Medium', startdate='2022-01-05', enddate='2022-01-05', status='Backlog', assignto='David')
       
        # delete 
        response = self.client.delete('/delete/task/5')
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
        response_content = response.content.decode('utf-8')
        self.assertJSONEqual(response_content, {"detail": "Not found."})
        
        response = self.client.delete('/delete/task/1')
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)    
        



