import sys
import os
import re
import pytest
import inspect
sys.path.append(os.getcwd())
from task import tests


@pytest.fixture
def inspect_get_sourcecode(obj):
    source_without_comment = re.sub(r"\s*\#.*", " ", inspect.getsource(obj))
    if inspect.getdoc(obj):
        return inspect.cleandoc(source_without_comment).replace(inspect.getdoc(obj), "").replace('"""', "")
    return source_without_comment


@pytest.mark.parametrize("obj", [tests.TestCase.test_add_task_without_title])
def test_add_task_without_title(inspect_get_sourcecode):   
    code = inspect_get_sourcecode.replace('"', "'")
    assert "{\n            'title': '',\n            'priority': 'Urgent',\n            'startdate': '2022-01-01',\n            'enddate': '2022-01-02',\n            'status': 'In Progress',\n            'assignto': 'Mark',\n        }" in code
    assert "post" in code or "POST" in code and "/add/task" in code and "HTTP_400_BAD_REQUEST" in code and "assert" in code and "{'title': ['This field may not be blank.']}" in code


@pytest.mark.parametrize("obj", [tests.TestCase.test_add_task_without_priority])
def test_add_task_without_priority(inspect_get_sourcecode):   
    code = inspect_get_sourcecode.replace('"', "'")
    assert "{\n            'title': 'Fix Bug',\n            'priority': '',\n            'startdate': '2022-01-01',\n            'enddate': '2022-01-02',\n            'status': 'In Progress',\n            'assignto': 'Mark',\n        }" in code
    assert "post" in code or "POST" in code and "/add/task" in code and "HTTP_400_BAD_REQUEST" in code and "assert" in code and "{'priority':['\\'\\' is not a valid choice.']}" in code
   

@pytest.mark.parametrize("obj", [tests.TestCase.test_add_task_without_startdate])
def test_add_task_without_startdate(inspect_get_sourcecode):   
    code = inspect_get_sourcecode.replace('"', "'")
    assert "{\n            'title': 'Fix Bug',\n            'priority': 'Urgent',\n            'startdate': '',\n            'enddate': '2022-01-02',\n            'status': 'In Progress',\n            'assignto': 'Mark',\n        }" in code
    assert "post" in code or "POST" in code and "/add/task" in code and "HTTP_400_BAD_REQUEST" in code and "assert" in code and "{'startdate':['Date has wrong format. Use one of these formats instead: YYYY-MM-DD.']}" in code


@pytest.mark.parametrize("obj", [tests.TestCase.test_add_task_with_incorrect_enddate_format])
def test_add_task_with_incorrect_enddate_format(inspect_get_sourcecode):   
    code = inspect_get_sourcecode.replace('"', "'")
    assert "{\n            'title': 'Fix Bug',\n            'priority': 'Urgent',\n            'startdate': '2022-01-01',\n            'enddate': '01-02-2022',\n            'status': 'In Progress',\n            'assignto': 'Mark',\n        }" in code
    assert "post" in code or "POST" in code and "/add/task" in code and "HTTP_400_BAD_REQUEST" in code and "assert" in code and "{'enddate':['Date has wrong format. Use one of these formats instead: YYYY-MM-DD.']})" in code
    

@pytest.mark.parametrize("obj", [tests.TestCase.test_add_task_without_status])
def test_add_task_without_status(inspect_get_sourcecode):   
    code = inspect_get_sourcecode.replace('"', "'")
    assert "{\n            'title': 'Fix Bug',\n            'priority': 'Urgent',\n            'startdate': '2022-01-01',\n            'enddate': '2022-01-02',\n            'status': '',\n            'assignto': 'Mark',\n        }" in code
    assert "post" in code or "POST" in code and "/add/task" in code and "HTTP_400_BAD_REQUEST" in code and "assert" in code and "{'status':['\\'\\' is not a valid choice.']}" in code


@pytest.mark.parametrize("obj", [tests.TestCase.test_add_task_without_assignto])
def test_add_task_without_assignto(inspect_get_sourcecode):   
    code = inspect_get_sourcecode.replace('"', "'")
    assert "{\n            'title': 'Fix Bug',\n            'priority': 'Urgent',\n            'startdate': '2022-01-01',\n            'enddate': '2022-01-02',\n            'status': 'In Progress',\n            'assignto': '',\n        }" in code
    assert "post" in code or "POST" in code and "/add/task" in code and "HTTP_400_BAD_REQUEST" in code and "assert" in code and "{'assignto':['This field may not be blank.']}" in code
    

@pytest.mark.parametrize("obj", [tests.TestCase.test_add_task])
def test_add_task(inspect_get_sourcecode):   
    code = inspect_get_sourcecode.replace('"', "'")
    assert "{\n            'title': 'Fix Bug',\n            'priority': 'Urgent',\n            'startdate': '2022-01-01',\n            'enddate': '2022-01-02',\n            'status': 'In Progress',\n            'assignto': 'Mark',\n        }" in code
    assert "post" in code or "POST" in code and "/add/task" in code and "HTTP_201_CREATED" in code and "assert" in code and "{'message':'Task added successfully.'}" in code
  

@pytest.mark.parametrize("obj", [tests.TestCase.test_list_task])
def test_list_task(inspect_get_sourcecode):   
    code = inspect_get_sourcecode.replace('"', "'")
    assert "get" in code or "GET" in code and "/list/task" in code and "HTTP_200_OK" in code and "assert" in code
    assert "[\n                {\n                    'id': 1,\n                    'title': 'Fix Bug',\n                    'priority': 'Urgent',\n                    'startdate': '2022-01-01',\n                    'enddate': '2022-01-02',\n                    'status': 'In Progress',\n                    'assignto': 'Mark',\n                },\n                {\n                    'id': 2,\n                    'title': 'Resolve Tickets',\n                    'priority': 'Low',\n                    'startdate': '2022-01-03',\n                    'enddate': '2022-01-04',\n                    'status': 'Backlog',\n                    'assignto': 'John',\n                },\n                {\n                    'id': 3,\n                    'title': 'Azure Session',\n                    'priority': 'Medium',\n                    'startdate': '2022-01-05',\n                    'enddate': '2022-01-05',\n                    'status': 'Backlog',\n                    'assignto': 'David',\n                },\n            ]" in code


@pytest.mark.parametrize("obj", [tests.TestCase.test_filter_task])
def test_filter_task(inspect_get_sourcecode):   
    code = inspect_get_sourcecode.replace('"', "'")
    assert "get" in code or "GET" in code and "/filter/task/?status=Backlog" in code and "HTTP_200_OK" in code and "assert" in code
    assert "[\n                {\n                    'id': 2,\n                    'title': 'Resolve Tickets',\n                    'priority': 'Low',\n                    'startdate': '2022-01-03',\n                    'enddate': '2022-01-04',\n                    'status': 'Backlog',\n                    'assignto': 'John',\n                },\n                {\n                    'id': 3,\n                    'title': 'Azure Session',\n                    'priority': 'Medium',\n                    'startdate': '2022-01-05',\n                    'enddate': '2022-01-05',\n                    'status': 'Backlog',\n                    'assignto': 'David',\n                },\n            ]" in code
    

@pytest.mark.parametrize("obj", [tests.TestCase.test_update_task])
def test_update_task(inspect_get_sourcecode):   
    code = inspect_get_sourcecode.replace('"', "'")
    assert "{'enddate': '2022-01-04'}" in code
    assert "patch" in code or "PATCH" in code and "/update/task/4" in code and "HTTP_404_NOT_FOUND" in code and "assert" in code and "{'detail':'Not found.'}" in code

    assert "{'enddate': '2022-01-04'}" in code
    assert "patch" in code or "PATCH" in code and "/update/task/2" in code and "HTTP_200_OK" in code and "assert" in code  
    assert "{\n                'id': 2,\n                'title': 'Resolve Tickets',\n                'priority': 'Low',\n                'startdate': '2022-01-03',\n                'enddate': '2022-01-04',\n                'status': 'Backlog',\n                'assignto': 'John',\n            }" in code


@pytest.mark.parametrize("obj", [tests.TestCase.test_delete_task])
def test_delete_task(inspect_get_sourcecode):   
    code = inspect_get_sourcecode.replace('"', "'")
    assert "delete" in code or "DELETE" in code and "/delete/task/5" in code and "HTTP_404_NOT_FOUND" in code and "assert" in code and "{'detail': 'Not found.'}" in code    
    assert "delete" in code or "DELETE" in code and "/delete/task/1" in code and "HTTP_204_NO_CONTENT" in code and "assert" in code 



