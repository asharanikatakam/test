from django.urls import path
from .views import AddView, ListView, FilterView, UpdateView, DeleteView


urlpatterns = [
    path('add/task', AddView.as_view()),
    path('list/task', ListView.as_view()),
    path('filter/task/', FilterView.as_view()),
    path('update/task/<pk>', UpdateView.as_view()),
    path('delete/task/<pk>', DeleteView.as_view()),
]



