from django.shortcuts import render
from rest_framework import generics, status
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from .models import Task
from .serializers import TaskSerializer


# Method to add a task
class AddView(generics.CreateAPIView):
    serializer_class = TaskSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        return Response(data={"message": "Task added successfully."}, status=status.HTTP_201_CREATED)


# Method to list a added tasks
class ListView(generics.ListAPIView):
    serializer_class = TaskSerializer
    queryset = Task.objects.all()


# Method to filter task based on status
class FilterView(generics.ListAPIView):
    serializer_class = TaskSerializer
    queryset = Task.objects.all()
    filter_backends = (DjangoFilterBackend,)
    filter_fields = ('status',)
    

# Method to update a task
class UpdateView(generics.RetrieveUpdateAPIView):
    serializer_class = TaskSerializer
    queryset = Task.objects.all()

    def update(self, request, *args, **kwargs):
        response = super().update(request, *args, **kwargs)
        return Response(response.data, status=status.HTTP_200_OK)
       

# Method to delete a task
class DeleteView(generics.RetrieveDestroyAPIView):
    serializer_class = TaskSerializer
    queryset = Task.objects.all()


