from django.test import TestCase
from rest_framework import status
from rest_framework.test import APITestCase
from rest_framework.test import APIClient
from rest_framework.utils import json


class TestCase(APITestCase):

    def setUp(self):
        self.client=APIClient()

    
    def test_add_task_without_title(self):
        '''
        In this method, you should send the request to '/add/task' URL with the following data payload 
        {'title': '', 'priority': 'Urgent', 'startdate': '2022-01-01', 'enddate': '2022-01-02', 'status': 'In Progress', 'assignto': 'Mark'}
        assert the response status code it should contain HTTP_400_BAD_REQUEST
        assert the JSON response it should contain {"title": ["This field may not be blank."]}.
        (Note: Don't change any payload order.)
        '''
        assert None


    def test_add_task_without_priority(self):
        '''
        In this method, you should send the request to '/add/task' URL with the following data payload 
        {'title': 'Fix Bug', 'priority': '', 'startdate': '2022-01-01', 'enddate': '2022-01-02', 'status': 'In Progress', 'assignto': 'Mark'}
        assert the response status code it should contain HTTP_400_BAD_REQUEST.
        assert the JSON response it should contain {"priority": ["\"\" is not a valid choice."]}.
        '''
        assert None


    def test_add_task_without_startdate(self):
        '''
        In this method, you should send the request to '/add/task' URL with the following data payload 
        {'title': 'Fix Bug', 'priority': 'Urgent', 'startdate': '', 'enddate': '2022-01-02', 'status': 'In Progress', 'assignto': 'Mark'}
        assert the response status code it should contain HTTP_400_BAD_REQUEST.
        assert the JSON response it should contain {"startdate": ["Date has wrong format. Use one of these formats instead: YYYY-MM-DD."]}.
        '''
        assert None


    def test_add_task_with_incorrect_enddate_format(self):
        '''
        In this method, you should send the request to '/add/task' URL with the following data payload 
        {'title': 'Fix Bug', 'priority': 'Urgent', 'startdate': '2022-01-01', 'enddate': '01-02-2022', 'status': 'In Progress', 'assignto': 'Mark'}
        assert the response status code it should contain HTTP_400_BAD_REQUEST.
        assert the JSON response it should contain {"enddate": ["Date has wrong format. Use one of these formats instead: YYYY-MM-DD."]}.
        '''
        assert None
    

    def test_add_task_without_status(self):
        '''
        In this method, you should send the request to '/add/task' URL with the following data payload 
        {'title': 'Fix Bug', 'priority': 'Urgent', 'startdate': '2022-01-01', 'enddate': '2022-01-02', 'status': '', 'assignto': 'Mark'}
        assert the response status code it should contain HTTP_400_BAD_REQUEST.
        assert the JSON response it should contain {"status": ["\"\" is not a valid choice."]}.
        '''
        assert None


    def test_add_task_without_assignto(self):
        '''
        In this method, you should send the request to '/add/task' URL with the following data payload 
        {'title': 'Fix Bug', 'priority': 'Urgent', 'startdate': '2022-01-01', 'enddate': '2022-01-02', 'status': 'In Progress', 'assignto': ''}
        assert the response status code it should contain HTTP_400_BAD_REQUEST.
        assert the JSON response it should contain {"assignto": ["This field may not be blank."]}.
        '''
        assert None


    def test_add_task(self):
        '''
        In this method, you should send the request to '/add/task' URL with the following data payload 
        {'title': 'Fix Bug', 'priority': 'Urgent', 'startdate': '2022-01-01', 'enddate': '2022-01-02', 'status': 'In Progress', 'assignto': 'Mark'}
        assert the response status code it should contain HTTP_201_CREATED.
        assert the JSON response it should contain {"message": "Task added successfully."}.
        '''
        assert None
    

    def test_list_task(self):
        '''
        In this method, you should create a following objects using Task model,
        (title='Fix Bug', priority='Urgent', startdate='2022-01-01', enddate='2022-01-02', status= 'In Progress', assignto='Mark') 
        (title='Resolve Tickets', priority='Low', startdate='2022-01-03', enddate='2022-01-04', status='Backlog', assignto='John')
        (title='Azure Session', priority='Medium', startdate='2022-01-05', enddate='2022-01-05', status='Backlog', assignto='David')
        and send the request to '/list/task' URL
        assert the response status code it should contain HTTP_200_OK.
        assert the JSON response it should contain [{"id": 1, "title": "Fix Bug", "priority": "Urgent", "startdate": "2022-01-01", "enddate": "2022-01-02", "status": "In Progress", "assignto": "Mark"}, {"id": 2, "title": "Resolve Tickets", "priority": "Low", "startdate": "2022-01-03", "enddate": "2022-01-04", "status": "Backlog", "assignto": "John"}, {"id": 3, "title": "Azure Session", "priority": "Medium", "startdate": "2022-01-05", "enddate": "2022-01-05", "status": "Backlog", "assignto": "David"}].
        '''
        assert None


    def test_filter_task(self):
        '''
        In this method, you should create a following objects using Task model,
        (title='Fix Bug', priority='Urgent', startdate='2022-01-01', enddate='2022-01-02', status= 'In Progress', assignto='Mark') 
        (title='Resolve Tickets', priority='Low', startdate='2022-01-03', enddate='2022-01-04', status='Backlog', assignto='John')
        (title='Azure Session', priority='Medium', startdate='2022-01-05', enddate='2022-01-05', status='Backlog', assignto='David')
        and send the request to '/filter/task/?status=Backlog' URL
        assert the response status code it should contain HTTP_200_OK.
        assert the JSON response it should contain [{"id": 2, "title": "Resolve Tickets", "priority": "Low", "startdate": "2022-01-03", "enddate": "2022-01-04", "status": "Backlog", "assignto": "John"}, {"id": 3, "title": "Azure Session", "priority": "Medium", "startdate": "2022-01-05", "enddate": "2022-01-05", "status": "Backlog", "assignto": "David"}].
        '''
        assert None


    def test_update_task(self):
        '''
        In this method, you should create a following objects using Task model,
        (title='Fix Bug', priority='Urgent', startdate='2022-01-01', enddate='2022-01-02', status= 'In Progress', assignto='Mark') 
        (title='Resolve Tickets', priority='Low', startdate='2022-01-03', enddate='2022-01-04', status='Backlog', assignto='John')
        (title='Azure Session', priority='Medium', startdate='2022-01-05', enddate='2022-01-05', status='Backlog', assignto='David')
        
        Send the request to '/update/task/4' URL with the following data payload {'enddate': '2022-01-04'}
        assert the response status code it should contain HTTP_404_NOT_FOUND.
        assert the JSON response it should contain {"detail": "Not found."}.

        Send the request to '/update/task/2' URL with the following data payload {'enddate': '2022-01-04'}
        assert the response status code it should contain HTTP_200_OK.
        assert the JSON response it should contain {"id": 2, "title": "Resolve Tickets", "priority": "Low", "startdate": "2022-01-03", "enddate": "2022-01-04", "status": "Backlog", "assignto": "John"}.
        '''
        assert None


    def test_delete_task(self):
        '''
        In this method, you should create a following objects using Task model,
        (title='Fix Bug', priority='Urgent', startdate='2022-01-01', enddate='2022-01-02', status= 'In Progress', assignto='Mark') 
        (title='Resolve Tickets', priority='Low', startdate='2022-01-03', enddate='2022-01-04', status='Backlog', assignto='John')
        (title='Azure Session', priority='Medium', startdate='2022-01-05', enddate='2022-01-05', status='Backlog', assignto='David')
        
        Send the request to '/delete/task/5' URL  
        assert the response status code it should contain HTTP_404_NOT_FOUND.
        assert the JSON response it should contain {"detail": "Not found."}.
         
        Send the request to '/delete/task/1' URL
        assert the response status code it should contain HTTP_204_NO_CONTENT.
        '''
        assert None
    





