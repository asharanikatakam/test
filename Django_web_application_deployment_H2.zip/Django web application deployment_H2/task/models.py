from django.db import models


class Task(models.Model):
    PRIORITY_OPTIONS = [
        ('Urgent', 'Urgent'),
        ('Important', 'Important'),
        ('Medium', 'Medium'),
        ('Low', 'Low'),
    ]

    STATUS_OPTIONS = [
        ('Backlog', 'Backlog'),
        ('In Progress', 'In Progress'),
        ('Done', 'Done'),
    ]


    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=100)
    priority = models.CharField(max_length=50, choices=PRIORITY_OPTIONS)
    startdate = models.DateField()
    enddate = models.DateField()
    status = models.CharField(max_length=50, default="Backlog", choices=STATUS_OPTIONS)
    assignto = models.CharField(max_length=50)

