#!/bin/sh 

score=0 

projloc=~/Desktop/Project/wingst5-may2022-hardchallenge2
validationloc=~/Desktop/Project/projectvalidation/wingst5-may2022-hardchallenge2

if [ -d "$projloc" ]; then
cp ${validationloc}/score.py ${projloc} 
cd ${projloc};
python3 -m black task/tests.py
python3 -m pytest -p no:warnings -o junit_family=legacy --junitxml=unit.xml score.py
fi


if [ -e unit.xml ]; then
tests_count=$(cat unit.xml | grep -oE 'tests\="[0-9]{1,2}"' | grep -oE '[0-9]{1,2}');   
errors_count=$(cat unit.xml | grep -oE 'errors\="[0-9]{1,2}"' | grep -oE '[0-9]{1,2}');    
failure_count=$(cat unit.xml | grep -oE 'failures\="[0-9]{1,2}"' | grep -oE '[0-9]{1,2}');    
totalFailure=$(( $errors_count + $failure_count ));
totalScore=$(( $tests_count - $totalFailure ));
totalPercent=$(printf %.$2f $(echo "$totalScore/$tests_count*50" | bc -l));
echo "{temp_score:$totalPercent}";
else 
echo "unit.xml is not generated";   
echo "{temp_score:0}";
fi


sudo docker stop kanbanboard_app_container
sudo docker rm kanbanboard_app_container 
sudo docker network rm wingst5may2022hardchallenge2_app_network
sudo docker volume rm wingst5may2022hardchallenge2_app_volume
sudo docker rmi kanbanboard_app_image
# sudo docker rmi python:3 
sudo docker-compose up -d

# Sleep time given to get the container up and running
sleep 5

# Checking Dockerfile and docker-compose.yml file
(sudo find ~/Desktop/Project/wingst5-may2022-hardchallenge2/Dockerfile) > /dev/null 2>&1; 
if [ $? -eq 0 ]; then 
score=$((score + 5)) && echo 'p1' 
fi; 

(sudo grep -e "FROM" -e "WORKDIR" -e "COPY" -e "python:3" -e "app" ~/Desktop/Project/wingst5-may2022-hardchallenge2/Dockerfile) > /dev/null 2>&1; 
if [ $? -eq 0 ]; then 
score=$((score + 5)) && echo 'p2' 
fi; 

(sudo find ~/Desktop/Project/wingst5-may2022-hardchallenge2/docker-compose.yml) > /dev/null 2>&1; 
if [ $? -eq 0 ]; then 
score=$((score + 5)) && echo 'p3' 
fi; 

(sudo grep -e "ports" -e "8085:8000" -e "networks" -e "app_network" -e "volumes" -e "app_volume" ~/Desktop/Project/wingst5-may2022-hardchallenge2/docker-compose.yml) > /dev/null 2>&1; 
if [ $? -eq 0 ]; then 
score=$((score + 5)) && echo 'p4' 
fi; 

# Checking container and images 
if [ `eval sudo docker ps -a | grep -o -e 'kanbanboard_app_container' | wc -l` -ge 1 ] 
then 
score=$((score + 5)) && echo 'p5' 
fi; 

if [ `eval sudo docker images | grep -o -e 'kanbanboard_app_image' | wc -l` -ge 1 ] 
then 
score=$(( score + 5 )) && echo 'p6' 
fi; 

if [ `eval sudo docker images | grep -o -e 'python' | wc -l` -ge 1 ] 
then 
score=$(( score + 5 )) && echo 'p7' 
fi; 

# Checking network and volume 
if [ `eval sudo docker volume ls | grep -o -e 'wingst5may2022hardchallenge2_app_volume' | wc -l` -eq 1 ] 
then 
score=$((score + 5)) && echo 'p8' 
fi; 

if [ `eval sudo docker network ls | grep -o -e 'wingst5may2022hardchallenge2_app_network' | wc -l` -eq 1 ] 
then 
score=$((score + 5)) && echo 'p9' 
fi; 

# Checking the output 
(curl http://localhost:8085/add/task/ | grep "kanbanboard.urls") 
if [ $? -eq 0 ]; then 
score=$((score + 5)) && echo "p10" 
fi; 


cd ~ 
sum=`expr $totalPercent + $score`
echo "{"SCORE":"$sum"}" 
 
 
