#!/bin/sh
sudo rm -f ~/Desktop/Project/wingst5-may2022-hardchallenge2/score.py
sudo apt install python3-pip --fix-missing -y
pip3 install -r requirements.txt
python3 manage.py makemigrations
python3 manage.py migrate
