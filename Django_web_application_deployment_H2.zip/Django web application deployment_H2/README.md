# WingsT5-May2022-HardChallenge2

WingsT5-May2022-HardChallenge2-DevOps
